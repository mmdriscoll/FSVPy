# fsvpy

This package is designed to locate and characterize fluorescent streaks in 
microscope images for flow velocimetry applications.  The fetures are 
illustrated in the included python notebook fsvpy_tutorial
